import java.util.Scanner;

import javax.swing.plaf.synth.SynthOptionPaneUI;

public class Aiis 
{
	public static void main(String[] args) 
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter 1 line ");
		String st = s.nextLine();
		System.out.println("Enter 2 line");
		String st2 = s.nextLine();
		System.out.println("Enter 3 line");
	}
}
